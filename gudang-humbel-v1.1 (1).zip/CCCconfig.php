<?php
/**
 * Konfigurasi Koneksi Database MySQL (cPanel / phpMyAdmin)
 *
 * PETUNJUK PENGISIAN DI CPANEL:
 * 1. Buka cPanel -> "MySQL Databases" (atau "Manage My Databases").
 * 2. Buat Database baru (misal: usercpanel_gudang).
 * 3. Buat User MySQL baru & catat password-nya (misal: usercpanel_admin).
 * 4. Tambahkan User tersebut ke Database dengan hak akses "ALL PRIVILEGES".
 * 5. Isi 4 variabel di bawah sesuai data dari cPanel Anda.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'hump6894_gdkain');
define('DB_USER', 'hump6894_gdkain');
define('DB_PASS', '10203040@kain');
define('DB_CHARSET', 'utf8mb4');

// Opsional: batasi domain asal jika frontend dan backend beda domain (contoh: 'https://domainanda.com')
// Kosongkan '*' jika berada di domain cPanel yang sama (public_html + public_html/api)
define('CORS_ALLOW_ORIGIN', '*');
