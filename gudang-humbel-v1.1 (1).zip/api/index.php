<?php
/**
 * REST API PHP untuk Aplikasi Gudang Humbel (cPanel + MySQL / phpMyAdmin)
 * Letakkan folder `api/` ini di dalam `public_html/api/` pada cPanel Anda.
 */

require_once __DIR__ . '/config.php';

// CORS & JSON Headers
$origin = defined('CORS_ALLOW_ORIGIN') ? CORS_ALLOW_ORIGIN : '*';
header("Access-Control-Allow-Origin: {$origin}");
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

function jsonResponse($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function getPdo(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        jsonResponse([
            'ok' => false,
            'error' => 'Koneksi database MySQL gagal. Periksa konfigurasi di api/config.php.'
        ], 500);
    }
}

// Parse request path relative to /api/
$requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$scriptDir = rtrim(dirname($scriptName), '/');

if ($scriptName !== '' && strpos($requestUri, $scriptName) === 0) {
    $relativePath = substr($requestUri, strlen($scriptName));
} elseif ($scriptDir !== '' && strpos($requestUri, $scriptDir) === 0) {
    $relativePath = substr($requestUri, strlen($scriptDir));
} else {
    $relativePath = $requestUri;
}
$relativePath = trim($relativePath, '/');
// Support query fallback ?route=... or PATH_INFO
if ($relativePath === '' && !empty($_SERVER['PATH_INFO'])) {
    $relativePath = trim((string)$_SERVER['PATH_INFO'], '/');
}
if ($relativePath === '' && isset($_GET['route'])) {
    $relativePath = trim((string)$_GET['route'], '/');
}

$segments = $relativePath === '' ? [] : explode('/', $relativePath);
$method = $_SERVER['REQUEST_METHOD'];

// Health check (also verifies whether tables from .sql have been imported)
if (($segments[0] ?? '') === 'health' || ($segments[0] ?? '') === '') {
    $pdo = getPdo();
    $pdo->query('SELECT 1');
    $tableCheck = $pdo->query("SHOW TABLES LIKE 'materials'")->fetch();
    jsonResponse([
        'ok' => true,
        'database' => DB_NAME,
        'status' => 'connected',
        'tablesReady' => (bool)$tableCheck,
        'phpVersion' => PHP_VERSION
    ]);
}

// Table schema mapping: TS camelCase <-> MySQL snake_case
function getTableSchemas(): array {
    return [
        'warehouses' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'code' => ['col' => 'code', 'type' => 'str'],
            'name' => ['col' => 'name', 'type' => 'str'],
            'description' => ['col' => 'description', 'type' => 'str'],
            'isRetailAvailable' => ['col' => 'is_retail_available', 'type' => 'bool'],
            'isActive' => ['col' => 'is_active', 'type' => 'bool'],
        ],
        'materials' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'sku' => ['col' => 'sku', 'type' => 'str'],
            'name' => ['col' => 'name', 'type' => 'str'],
            'category' => ['col' => 'category', 'type' => 'str'],
            'unit' => ['col' => 'unit', 'type' => 'str'],
            'warehouseStocks' => ['col' => 'warehouse_stocks', 'type' => 'json'],
            'minStockAlert' => ['col' => 'min_stock_alert', 'type' => 'float'],
            'averageBuyPrice' => ['col' => 'average_buy_price', 'type' => 'float'],
            'suggestedRetailPrice' => ['col' => 'suggested_retail_price', 'type' => 'float'],
            'color' => ['col' => 'color', 'type' => 'str'],
            'colorHex' => ['col' => 'color_hex', 'type' => 'str'],
            'specifications' => ['col' => 'specifications', 'type' => 'str'],
            'defaultVendorId' => ['col' => 'default_vendor_id', 'type' => 'str'],
            'supplierName' => ['col' => 'supplier_name', 'type' => 'str'],
            'dyeLotOrBatch' => ['col' => 'dye_lot_or_batch', 'type' => 'str'],
            'poNumber' => ['col' => 'po_number', 'type' => 'str'],
            'poId' => ['col' => 'po_id', 'type' => 'str'],
            'purchaseDate' => ['col' => 'purchase_date', 'type' => 'str'],
            'poQuantity' => ['col' => 'po_quantity', 'type' => 'float'],
            'barcode' => ['col' => 'barcode', 'type' => 'str'],
            'isRetailReady' => ['col' => 'is_retail_ready', 'type' => 'bool'],
            'notes' => ['col' => 'notes', 'type' => 'str'],
            'lastUpdated' => ['col' => 'last_updated', 'type' => 'str'],
        ],
        'vendors' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'name' => ['col' => 'name', 'type' => 'str'],
            'phone' => ['col' => 'phone', 'type' => 'str'],
            'address' => ['col' => 'address', 'type' => 'str'],
            'category' => ['col' => 'category', 'type' => 'json'],
            'paymentTerms' => ['col' => 'payment_terms', 'type' => 'str'],
            'rating' => ['col' => 'rating', 'type' => 'float'],
            'notes' => ['col' => 'notes', 'type' => 'str'],
        ],
        'purchases' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'poNumber' => ['col' => 'po_number', 'type' => 'str'],
            'vendorId' => ['col' => 'vendor_id', 'type' => 'str'],
            'vendorName' => ['col' => 'vendor_name', 'type' => 'str'],
            'warehouseId' => ['col' => 'warehouse_id', 'type' => 'str'],
            'warehouseName' => ['col' => 'warehouse_name', 'type' => 'str'],
            'date' => ['col' => 'date', 'type' => 'str'],
            'status' => ['col' => 'status', 'type' => 'str'],
            'items' => ['col' => 'items', 'type' => 'json'],
            'subtotalItems' => ['col' => 'subtotal_items', 'type' => 'float'],
            'shippingCost' => ['col' => 'shipping_cost', 'type' => 'float'],
            'expeditionName' => ['col' => 'expedition_name', 'type' => 'str'],
            'trackingNumber' => ['col' => 'tracking_number', 'type' => 'str'],
            'includeShippingInHpp' => ['col' => 'include_shipping_in_hpp', 'type' => 'bool'],
            'totalAmount' => ['col' => 'total_amount', 'type' => 'float'],
            'notes' => ['col' => 'notes', 'type' => 'str'],
        ],
        'daily_usage' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'spkNumber' => ['col' => 'spk_number', 'type' => 'str'],
            'reportNumber' => ['col' => 'report_number', 'type' => 'str'],
            'customerName' => ['col' => 'customer_name', 'type' => 'str'],
            'customerPhone' => ['col' => 'customer_phone', 'type' => 'str'],
            'productName' => ['col' => 'product_name', 'type' => 'str'],
            'targetOutputPcs' => ['col' => 'target_output_pcs', 'type' => 'int'],
            'date' => ['col' => 'date', 'type' => 'str'],
            'warehouseId' => ['col' => 'warehouse_id', 'type' => 'str'],
            'warehouseName' => ['col' => 'warehouse_name', 'type' => 'str'],
            'operatorName' => ['col' => 'operator_name', 'type' => 'str'],
            'items' => ['col' => 'items', 'type' => 'json'],
            'totalCost' => ['col' => 'total_cost', 'type' => 'float'],
            'wastePercentageEstimated' => ['col' => 'waste_percentage_estimated', 'type' => 'float'],
            'notes' => ['col' => 'notes', 'type' => 'str'],
            'returns' => ['col' => 'returns', 'type' => 'json'],
            'totalReturnedCost' => ['col' => 'total_returned_cost', 'type' => 'float'],
        ],
        'retail_customers' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'name' => ['col' => 'name', 'type' => 'str'],
            'phone' => ['col' => 'phone', 'type' => 'str'],
            'address' => ['col' => 'address', 'type' => 'str'],
            'company' => ['col' => 'company', 'type' => 'str'],
            'creditLimit' => ['col' => 'credit_limit', 'type' => 'float'],
            'notes' => ['col' => 'notes', 'type' => 'str'],
            'createdAt' => ['col' => 'created_at', 'type' => 'str'],
            'updatedAt' => ['col' => 'updated_at', 'type' => 'str'],
        ],
        'retail_sales' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'invoiceNumber' => ['col' => 'invoice_number', 'type' => 'str'],
            'date' => ['col' => 'date', 'type' => 'str'],
            'customerId' => ['col' => 'customer_id', 'type' => 'str'],
            'customerName' => ['col' => 'customer_name', 'type' => 'str'],
            'customerPhone' => ['col' => 'customer_phone', 'type' => 'str'],
            'warehouseId' => ['col' => 'warehouse_id', 'type' => 'str'],
            'warehouseName' => ['col' => 'warehouse_name', 'type' => 'str'],
            'items' => ['col' => 'items', 'type' => 'json'],
            'subtotalItems' => ['col' => 'subtotal_items', 'type' => 'float'],
            'shippingCost' => ['col' => 'shipping_cost', 'type' => 'float'],
            'expeditionName' => ['col' => 'expedition_name', 'type' => 'str'],
            'trackingNumber' => ['col' => 'tracking_number', 'type' => 'str'],
            'totalSell' => ['col' => 'total_sell', 'type' => 'float'],
            'totalHpp' => ['col' => 'total_hpp', 'type' => 'float'],
            'totalGrossProfit' => ['col' => 'total_gross_profit', 'type' => 'float'],
            'profitMarginPercent' => ['col' => 'profit_margin_percent', 'type' => 'float'],
            'paymentMethod' => ['col' => 'payment_method', 'type' => 'str'],
            'paymentStatus' => ['col' => 'payment_status', 'type' => 'str'],
            'amountPaid' => ['col' => 'amount_paid', 'type' => 'float'],
            'remainingDebt' => ['col' => 'remaining_debt', 'type' => 'float'],
            'dueDate' => ['col' => 'due_date', 'type' => 'str'],
            'paymentHistory' => ['col' => 'payment_history', 'type' => 'json'],
            'cashierName' => ['col' => 'cashier_name', 'type' => 'str'],
            'notes' => ['col' => 'notes', 'type' => 'str'],
        ],
        'transfers' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'transferNumber' => ['col' => 'transfer_number', 'type' => 'str'],
            'date' => ['col' => 'date', 'type' => 'str'],
            'fromWarehouseId' => ['col' => 'from_warehouse_id', 'type' => 'str'],
            'fromWarehouseName' => ['col' => 'from_warehouse_name', 'type' => 'str'],
            'toWarehouseId' => ['col' => 'to_warehouse_id', 'type' => 'str'],
            'toWarehouseName' => ['col' => 'to_warehouse_name', 'type' => 'str'],
            'materialId' => ['col' => 'material_id', 'type' => 'str'],
            'materialName' => ['col' => 'material_name', 'type' => 'str'],
            'quantity' => ['col' => 'quantity', 'type' => 'float'],
            'unit' => ['col' => 'unit', 'type' => 'str'],
            'transferredBy' => ['col' => 'transferred_by', 'type' => 'str'],
            'notes' => ['col' => 'notes', 'type' => 'str'],
        ],
        'users' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'name' => ['col' => 'name', 'type' => 'str'],
            'role' => ['col' => 'role', 'type' => 'str'],
            'customRoleTitle' => ['col' => 'custom_role_title', 'type' => 'str'],
            'email' => ['col' => 'email', 'type' => 'str'],
            'username' => ['col' => 'username', 'type' => 'str'],
            'password' => ['col' => 'password', 'type' => 'str'],
            'avatar' => ['col' => 'avatar', 'type' => 'str'],
            'avatarColor' => ['col' => 'avatar_color', 'type' => 'str'],
            'isCustomPermissions' => ['col' => 'is_custom_permissions', 'type' => 'bool'],
            'permissions' => ['col' => 'permissions', 'type' => 'json'],
        ],
        'reminders' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'time' => ['col' => 'time', 'type' => 'str'],
            'title' => ['col' => 'title', 'type' => 'str'],
            'description' => ['col' => 'description', 'type' => 'str'],
            'isActive' => ['col' => 'is_active', 'type' => 'bool'],
            'category' => ['col' => 'category', 'type' => 'str'],
            'days' => ['col' => 'days', 'type' => 'str'],
            'targetRole' => ['col' => 'target_role', 'type' => 'str'],
        ],
        'calendar_events' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'title' => ['col' => 'title', 'type' => 'str'],
            'date' => ['col' => 'date', 'type' => 'str'],
            'endDate' => ['col' => 'end_date', 'type' => 'str'],
            'time' => ['col' => 'time', 'type' => 'str'],
            'type' => ['col' => 'type', 'type' => 'str'],
            'description' => ['col' => 'description', 'type' => 'str'],
            'status' => ['col' => 'status', 'type' => 'str'],
            'relatedId' => ['col' => 'related_id', 'type' => 'str'],
        ],
        'notifications' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'title' => ['col' => 'title', 'type' => 'str'],
            'message' => ['col' => 'message', 'type' => 'str'],
            'type' => ['col' => 'type', 'type' => 'str'],
            'timestamp' => ['col' => 'timestamp', 'type' => 'str'],
            'read' => ['col' => 'is_read', 'type' => 'bool'],
            'linkTab' => ['col' => 'link_tab', 'type' => 'str'],
            'category' => ['col' => 'category', 'type' => 'str'],
            'deviceId' => ['col' => 'device_id', 'type' => 'str'],
            'authorName' => ['col' => 'author_name', 'type' => 'str'],
        ],
        'company_info' => [
            'id' => ['col' => 'id', 'type' => 'str'],
            'name' => ['col' => 'name', 'type' => 'str'],
            'tagline' => ['col' => 'tagline', 'type' => 'str'],
            'address' => ['col' => 'address', 'type' => 'str'],
            'city' => ['col' => 'city', 'type' => 'str'],
            'phone' => ['col' => 'phone', 'type' => 'str'],
            'whatsapp' => ['col' => 'whatsapp', 'type' => 'str'],
            'email' => ['col' => 'email', 'type' => 'str'],
            'website' => ['col' => 'website', 'type' => 'str'],
            'npwp' => ['col' => 'npwp', 'type' => 'str'],
            'bankAccount' => ['col' => 'bank_account', 'type' => 'str'],
            'receiptFooterNote' => ['col' => 'receipt_footer_note', 'type' => 'str'],
            'logoUrl' => ['col' => 'logo_url', 'type' => 'str'],
            'authorizedSigner' => ['col' => 'authorized_signer', 'type' => 'str'],
            'stampText' => ['col' => 'stamp_text', 'type' => 'str'],
        ],
    ];
}

function rowToFrontend(string $table, array $row, array $schema): array {
    $out = [];
    foreach ($schema as $tsKey => $meta) {
        $col = $meta['col'];
        if (!array_key_exists($col, $row)) continue;
        $val = $row[$col];
        if ($val === null) continue;

        switch ($meta['type']) {
            case 'bool':
                $out[$tsKey] = (bool)$val;
                break;
            case 'int':
                $out[$tsKey] = (int)$val;
                break;
            case 'float':
                $out[$tsKey] = (float)$val;
                break;
            case 'json':
                $decoded = json_decode((string)$val, true);
                $out[$tsKey] = $decoded !== null ? $decoded : [];
                break;
            default:
                $out[$tsKey] = (string)$val;
                break;
        }
    }
    if ($table === 'reminders' && array_key_exists('isActive', $out)) {
        $out['active'] = $out['isActive'];
    }
    return $out;
}

function upsertRecord(PDO $pdo, string $table, array $schema, array $input): void {
    if ($table === 'reminders' && !isset($input['isActive']) && isset($input['active'])) {
        $input['isActive'] = $input['active'];
    }
    if ($table === 'company_info' && empty($input['id'])) {
        $input['id'] = 'main';
    }

    $cols = [];
    $placeholders = [];
    $updates = [];
    $params = [];

    foreach ($schema as $tsKey => $meta) {
        $col = $meta['col'];
        $hasKey = array_key_exists($tsKey, $input);
        if (!$hasKey && $col !== 'id') continue;

        $val = $input[$tsKey] ?? null;
        $cols[] = "`{$col}`";
        $placeholders[] = ":{$col}";
        if ($col !== 'id') {
            $updates[] = "`{$col}` = VALUES(`{$col}`)";
        }

        if ($val === null) {
            $params[":{$col}"] = null;
        } elseif ($meta['type'] === 'bool') {
            $params[":{$col}"] = $val ? 1 : 0;
        } elseif ($meta['type'] === 'int') {
            $params[":{$col}"] = (int)$val;
        } elseif ($meta['type'] === 'float') {
            $params[":{$col}"] = (float)$val;
        } elseif ($meta['type'] === 'json') {
            $params[":{$col}"] = json_encode($val, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } else {
            $params[":{$col}"] = (string)$val;
        }
    }

    if (empty($params[':id'])) {
        jsonResponse(['ok' => false, 'error' => 'Field id wajib diisi'], 400);
    }
    if (empty($updates)) {
        $updates[] = '`id` = VALUES(`id`)';
    }

    $sql = sprintf(
        'INSERT INTO `%s` (%s) VALUES (%s) ON DUPLICATE KEY UPDATE %s',
        $table,
        implode(', ', $cols),
        implode(', ', $placeholders),
        implode(', ', $updates)
    );
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
}

// Reset dummy endpoint
if (($segments[0] ?? '') === 'reset-dummy' && $method === 'POST') {
    $pdo = getPdo();
    $tablesToTruncate = [
        'materials', 'purchases', 'daily_usage', 'retail_sales',
        'retail_customers', 'transfers', 'vendors', 'reminders',
        'calendar_events', 'notifications'
    ];
    foreach ($tablesToTruncate as $t) {
        $pdo->exec("DELETE FROM `{$t}`");
    }
    jsonResponse(['ok' => true, 'message' => 'Data dummy berhasil dibersihkan dari MySQL']);
}

$table = $segments[0] ?? '';
$schemas = getTableSchemas();

if (!array_key_exists($table, $schemas)) {
    jsonResponse(['ok' => false, 'error' => 'Tabel atau endpoint tidak ditemukan'], 404);
}

$schema = $schemas[$table];
$pdo = getPdo();

try {
    // GET /{table} or GET /company_info/main
    if ($method === 'GET') {
        if ($table === 'company_info' && ($segments[1] ?? '') === 'main') {
            $stmt = $pdo->prepare('SELECT * FROM `company_info` WHERE `id` = :id LIMIT 1');
            $stmt->execute([':id' => 'main']);
            $row = $stmt->fetch();
            jsonResponse($row ? rowToFrontend($table, $row, $schema) : (object)[]);
        }

        $stmt = $pdo->query("SELECT * FROM `{$table}`");
        $rows = $stmt->fetchAll();
        $result = array_map(fn($r) => rowToFrontend($table, $r, $schema), $rows);
        jsonResponse($result);
    }

    // POST /{table} or POST /{table}/bulk
    if ($method === 'POST') {
        $raw = file_get_contents('php://input');
        $payload = json_decode($raw ?: '{}', true);
        if (!is_array($payload)) {
            jsonResponse(['ok' => false, 'error' => 'Body JSON tidak valid'], 400);
        }

        $subAction = $segments[1] ?? '';

        if ($subAction === 'bulk') {
            $items = $payload['items'] ?? [];
            if (!is_array($items)) {
                jsonResponse(['ok' => false, 'error' => 'items harus berupa array'], 400);
            }
            $pdo->beginTransaction();
            try {
                foreach ($items as $item) {
                    if (is_array($item) && !empty($item['id'])) {
                        upsertRecord($pdo, $table, $schema, $item);
                    }
                }
                $pdo->commit();
                jsonResponse(['ok' => true, 'count' => count($items)]);
            } catch (Throwable $e) {
                $pdo->rollBack();
                jsonResponse(['ok' => false, 'error' => 'Gagal menyimpan bulk data: ' . $e->getMessage()], 500);
            }
        }

        if ($subAction === 'delete' && !empty($segments[2])) {
            $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE `id` = :id");
            $stmt->execute([':id' => $segments[2]]);
            jsonResponse(['ok' => true, 'deleted' => $segments[2]]);
        }

        upsertRecord($pdo, $table, $schema, $payload);
        jsonResponse(['ok' => true]);
    }

    // DELETE /{table}/{id}
    if ($method === 'DELETE') {
        $id = $segments[1] ?? '';
        if ($id === '') {
            jsonResponse(['ok' => false, 'error' => 'ID dokumen tidak ditemukan'], 400);
        }
        $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE `id` = :id");
        $stmt->execute([':id' => $id]);
        jsonResponse(['ok' => true, 'deleted' => $id]);
    }

    jsonResponse(['ok' => false, 'error' => 'Method tidak didukung'], 405);
} catch (Throwable $e) {
    jsonResponse(['ok' => false, 'error' => 'Kesalahan database PHP: ' . $e->getMessage()], 500);
}
