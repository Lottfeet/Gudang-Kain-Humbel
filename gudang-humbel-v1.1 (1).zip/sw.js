// Service Worker for KonveksiStok Pro Push Notifications
const CACHE_NAME = 'konveksi-cache-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Handle push events from Push API / server or local triggers
self.addEventListener('push', (event) => {
  let data = {
    title: 'KonveksiStok Pro',
    body: 'Pemberitahuan stok & operasional real-time.',
    icon: './favicon.ico',
    badge: './favicon.ico',
    tag: 'konveksi-alert',
    url: './'
  };

  if (event.data) {
    try {
      data = { ...data, ...event.data.json() };
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: data.icon,
    badge: data.badge,
    tag: data.tag || 'konveksi-notification',
    vibrate: [150, 80, 150],
    data: {
      url: data.url || './',
      linkTab: data.linkTab || 'dashboard'
    }
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Focus or open window when user clicks the notification banner
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const targetUrl = event.notification.data?.url || './';
  const targetTab = event.notification.data?.linkTab || 'dashboard';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      // If a window is already open, focus it and post a message to switch tab
      for (const client of windowClients) {
        if ('focus' in client) {
          client.focus();
          client.postMessage({
            type: 'NAVIGATE_TAB',
            tab: targetTab
          });
          return;
        }
      }
      // Otherwise open a new window
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
